import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class Robot {

    // instance variables
    private int x;
    private int y;
    private String facing;

    // Constructor
    public Robot() {
        this.x = -1;
        this.y = -1;
        this.facing = "none";
    }


    // Methods
    // Setters
    public boolean setX(int x) {
        boolean valid = false;
        if (x >= 0 && x <= 4) {
            this.x = x;
            valid = true;
        }
        return valid;
    }

    public boolean setY(int y) {
        boolean valid = false;
        if (y >= 0 && y <= 4) {
            this.y = y;
            valid = true;
        }
        return valid;
    }

    public boolean setFacing(String facing) {
        boolean valid = false;
        String userInput = facing.toUpperCase();
        //Check whether the user input is acceptable or not
        if (userInput.equals("NORTH") || userInput.equals("SOUTH") || userInput.equals("WEST") || userInput.equals("EAST")) {
            this.facing = userInput;
            valid = true;
        }
        return valid;
    }

    // Getters
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getFacing() {
        return facing;
    }

    // Functions || Methods
    // Place method which placing the robot onto the table
    public boolean place(int newX, int newY, String newFacing) {
        boolean valid = false;
        int previousX = this.getX();
        int previousY = this.getY();
        String previousFacing=this.getFacing();

        //check if all of the data input (x,y,facing) is correct, if not ,set back to the previous
        if (this.setX(newX) && this.setY(newY) && this.setFacing(newFacing)) {
            valid = true;
        } else {
            this.setX(previousX);
            this.setY(previousY);
            this.setFacing(previousFacing);
        }
        return valid;
    }

    // Move the robot 1 step forward based on it's direction
    public boolean move() {
        boolean valid = false;
        if (this.getFacing() != null) {
            if (this.getFacing().equals("NORTH")) {
                if (this.setY(this.getY() + 1)) {
                    valid = true;
                }
            } else if (this.getFacing().equals("WEST")) {
                if (this.setX(this.getX() - 1)) {
                    valid = true;
                }
            } else if (this.getFacing().equals("SOUTH")) {
                if (this.setY(this.getY() - 1)) {
                    valid = true;
                }
            } else if (this.getFacing().equals("EAST")) {
                if (this.setX(this.getX() + 1)) {
                    valid = true;
                }
            }
        }
        return valid;
    }

    //give report
    public String report() {
        String state;
        if (this.getX() != -1 && this.getY() != -1 && this.getFacing() != null) {
            state = "x : " + this.getX() + "\ny : " + this.getY() + "\nfacing : " + this.getFacing();
        } else {
            state = "You haven't place the robot into the table yet, please use place first!";
        }

        return state;
    }

    // turn left
    public boolean left() {
        boolean valid = false;
        if (this.getFacing() != null && !this.getFacing().equalsIgnoreCase("none") ) {
            if (this.getFacing().toUpperCase().equals("NORTH")) {
                this.setFacing("WEST");
            } else if (this.getFacing().toUpperCase().equals("WEST")) {
                this.setFacing("SOUTH");
            } else if (this.getFacing().toUpperCase().equals("SOUTH")) {
                this.setFacing("EAST");
            } else if (this.getFacing().toUpperCase().equals("EAST")) {
                this.setFacing("NORTH");
            }
            valid = true;
        }
        return valid;
    }

    //turn right
    public boolean right() {
        boolean valid = false;
        if (this.getFacing() != null && !this.getFacing().equalsIgnoreCase("none")) {
            if (this.getFacing().toUpperCase().equals("NORTH")) {
                this.setFacing("EAST");
            } else if (this.getFacing().toUpperCase().equals("EAST")) {
                this.setFacing("SOUTH");
            } else if (this.getFacing().toUpperCase().equals("SOUTH")) {
                this.setFacing("WEST");
            } else if (this.getFacing().toUpperCase().equals("WEST")) {
                this.setFacing("NORTH");
            }
            valid = true;
        }
        return valid;
    }

    // read the file and execute the file
    public boolean readfile(String filePath) {
        boolean valid = false;
        ArrayList<String> command = new ArrayList<String>();
        // read file into arraylist
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                command.add(line);
            }
            br.close();
            // iterate the arraylist and to the command
            for (int i = 0; i < command.size(); i++) {
                if (command.get(i).toUpperCase().contains("PLACE")) {
                    String data = command.get(i).toUpperCase().replaceAll("\\s+", "");
                    data = data.substring(5);
                    String[] placeData = data.split(",");
                    if (this.place(Integer.parseInt(placeData[0]), Integer.parseInt(placeData[1]), placeData[2])) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                } else if (command.get(i).toUpperCase().contains("MOVE")) {
                    if (this.move()) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                } else if (command.get(i).toUpperCase().contains("LEFT")) {
                    if (this.left()) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                } else if (command.get(i).toUpperCase().contains("RIGHT")) {
                    if (this.right()) {
                        valid = true;
                    } else {
                        valid = false;
                    }
                } else if (command.get(i).toUpperCase().contains("REPORT")) {
                    System.out.println(this.report());
                } else {
                    valid = false;
                }
                System.out.println(valid);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return valid;
    }

    // - -----------
    public static void main(String args[]) {
        System.out.println("Welcome to robot game");
        Robot robot1 = new Robot();
        boolean whileGameType = true;
        //asking keep asking which method user want to play
        while (whileGameType) {
            System.out.println("How would you like to play (1: file upload, 2: input manually) ?");
            Scanner scanner = new Scanner(System.in);
            if (scanner.hasNextInt()) {
                int gameType = scanner.nextInt();
                //user choose read file
                if (gameType == 1) {
                    robot1 = new Robot();
                    System.out.println("Can you please type in your file path! (e.g. c:/Users/testfile1.txt)");
                    Scanner scanFile = new Scanner(System.in);
                    String filePath = scanFile.nextLine();
                    boolean result=robot1.readfile(filePath);
                    if (!result) {
                        System.out.println("Error command in the file.");
                    }
                }
                //user choose input manually
                else if (gameType == 2) {
                    boolean test = true;
                    //keep asking what is the next move
                    while (test) {
                        System.out.println("What do you want to do ?\n1: Place the robot\n2: Move\n3: Left\n4: Right\n5: Report");
                        Scanner scanner2 = new Scanner(System.in);
                        if (scanner2.hasNextInt()) {
                            int userMove = scanner2.nextInt();
                            //place method
                            if (userMove == 1) {
                                System.out.println("PLACE ROBOT");
                                System.out.println("x location (0-4):");
                                Scanner scanner3 = new Scanner(System.in);
                                while (!scanner3.hasNextInt()) {
                                    System.out.println("Please enter a correct integer! (0-4)");
                                    System.out.println("x location :");
                                    scanner3 = new Scanner(System.in);
                                }
                                int newX = scanner3.nextInt();
                                System.out.println("x location (0-4):");
                                System.out.println("y location :");
                                Scanner scanner4 = new Scanner(System.in);
                                while (!scanner4.hasNextInt()) {
                                    System.out.println("Please enter a correct integer! (0-4)");
                                    System.out.println("y location :");
                                    scanner4 = new Scanner(System.in);
                                }
                                int newY = scanner4.nextInt();
                                System.out.println("facing direction (NORTH/WEST/SOUTH/EAST):");
                                Scanner scanner5 = new Scanner(System.in);
                                String newFacing = scanner5.nextLine();
                                while (!(newFacing.toUpperCase().equals("NORTH") || newFacing.toUpperCase().equals("WEST") ||
                                        newFacing.toUpperCase().equals("SOUTH") || newFacing.toUpperCase().equals("EAST"))) {
                                    System.out.println(newFacing);
                                    System.out.println("Please input the correct direction!");
                                    System.out.println("facing direction (NORTH/WEST/SOUTH/EAST):");
                                    scanner5 = new Scanner(System.in);
                                    newFacing = scanner5.nextLine();
                                }
                                boolean result = robot1.place(newX, newY, newFacing);
                                if (!result) {
                                    System.out.println("Placing failed, please follow the input rules");
                                }
                            }
                            //move method
                            else if (userMove == 2) {
                                boolean result = robot1.move();
                                if (!result) {
                                    System.out.println("Move failed!!\nPlease remember where you are currently facing and x location and " +
                                            "y location both should be between 0-4 inclusive");
                                }
                            }
                            //turn left
                            else if (userMove == 3) {
                                boolean result = robot1.left();
                                if (!result) {
                                    System.out.println("Turning left failed");
                                }
                            }
                            //turn right
                            else if (userMove == 4) {
                                boolean result = robot1.right();
                                if (!result) {
                                    System.out.println("Turning right failed");
                                }
                            }
                            //reporting
                            else if (userMove == 5) {
                                System.out.println(robot1.report());
                            } else {
                                System.out.println("Wrong input");
                            }
                        } else {
                            System.out.println("Please enter 1/2/3/4/5 or you need to place the robot first before choosing any other move");
                        }
                    }
                }
            } else {
                System.out.println("Wrong input, please input either 1 or 2 numerically! ");
            }

        }


    }
}
